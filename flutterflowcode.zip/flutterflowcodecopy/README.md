# HHH The Ride App
## Cooper Wolf, Tim Haxton, Jon Scales
## SWE Project  Spring 2025
### FLutterFlow Code 
This repository contains code copied from the flutterflow HHH-The Ride App  
Project ID  h-h-h-the-ride-app-8hkscw

to proplerly use github with the flutterflow program, one must subscribe.  Since
we don't want to spend any $$, this code has simply been copied and pasted into 
files.  

As files are modified in the flutterflow work environment (online - via web page), the
modified code will be updated here manually by a team of underpaid, malnurished scribes. 

